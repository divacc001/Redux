import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { v4 as uuidv4 } from "uuid";
import { addTask } from "../Redux/Action.js";
import { useDispatch } from "react-redux";
import '../Add.css'

function Add() {
  const dispatch = useDispatch();
  const [task, setTask] = useState({ id: "", text: "", done: false });

  const handleChange = (e) => {
    setTask({ ...task, id: uuidv4(), text: e.target.value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addTask(task));
    setTask({ ...task, text: "" });
  };
  return (
    <Form onSubmit={handleSubmit}>
          <div style={{display:"flex", flexDirection:"column", justifyContent:"center", alignItems:"center", gap:"20px"}}> 
            <Form.Label style={{fontWeight:"bold", marginTop:"2%"}}>Wecome back</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter task"
          onChange={handleChange}
          value={task.text}
          style={{width:"20%"}}
        />
      <Button variant="success" type="submit" className="custom-submit-button">
        Submit
      </Button>
         </div>
       
     
    </Form>
  );
}

export default Add;
