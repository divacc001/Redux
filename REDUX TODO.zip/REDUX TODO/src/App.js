import "bootstrap/dist/css/bootstrap.min.css";
import List from "./Components/List";
import Add from "./Components/Add";
function App() {
  return (
    <div>
      <Add />
      <List />
    </div>
  );
}
export default App;
